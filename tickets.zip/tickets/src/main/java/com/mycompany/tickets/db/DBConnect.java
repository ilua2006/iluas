package com.mycompany.tickets.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
    // Параметры подключения (без final, чтобы можно было менять)
    private String serverUrl; // Имя сервера
    private String dbName;    // Имя базы данных
    private Connection connection;
    private boolean readyToWork = false; // Флаг готовности к работе

    /**
     * Конструктор без параметров (по умолчанию)
     */
    public DBConnect() {
        this.serverUrl = "DESKTOP-CQ6SSNA\\SQLEXPRESS";
        this.dbName = "Ticket";
        readyToWork = checkConnection();
    }

    /**
     * Конструктор с параметрами — для передачи URL сервера и имени БД
     * @param serverUrl имя сервера (например, "DESKTOP-CQ6SSNA\\SQLEXPRESS")
     * @param dbName имя базы данных (например, "Ticket")
     */
    public DBConnect(String serverUrl, String dbName) {
        this.serverUrl = serverUrl;
        this.dbName = dbName;
        readyToWork = checkConnection(); // Сразу проверяем подключение
    }

    /**
     * Проверяет возможность подключения к серверу БД.
     * @return true, если подключение успешно
     */
    private boolean checkConnection() {
        Connection testConnection = createConnection();
        if (testConnection == null) {
            System.out.println("Не удалось подключиться к SQL Server:");
            System.out.println("Сервер: " + serverUrl);
            System.out.println("БД: " + dbName);
            System.out.println("Проверьте: запущен ли SQL Server, разрешены ли подключения.");
            return false;
        } else {
            try {
                testConnection.close();
                System.out.println("Успешное подключение к БД '" + dbName + "'!");
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    /**
     * Формирует строку подключения и устанавливает соединение.
     * @return Объект Connection или null при ошибке
     */
    private Connection createConnection() {
        String connStr = "jdbc:sqlserver://" + serverUrl +
                ";databaseName=" + dbName +
                ";integratedSecurity=true;" +
                "encrypt=false;trustServerCertificate=true";

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            return DriverManager.getConnection(connStr);
        } catch (ClassNotFoundException e) {
            System.err.println("Драйвер JDBC не найден!");
            e.printStackTrace();
            return null;
        } catch (SQLException ex) {
            System.err.println("Ошибка подключения к БД: " + ex.getMessage());
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Возвращает соединение с БД.
     * @return Connection объект или null, если подключение невозможно
     */
    public Connection getConnection() {
        if (!readyToWork) {
            System.out.println("Класс не готов к работе с БД. Проверьте параметры подключения.");
            return null;
        }
        return createConnection();
    }

    /**
     * Проверяет, готово ли соединение к работе.
     * @return true, если соединение установлено
     */
    public boolean isReadyToWork() {
        return readyToWork;
    }

    // Сеттеры для изменения параметров подключения
    public void setServerUrl(String serverUrl) { this.serverUrl = serverUrl; }
    public void setDbName(String dbName) { this.dbName = dbName; }
}